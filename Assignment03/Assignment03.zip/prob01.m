clear;
close all;
clc;

imagefiles=dir('.\places\Images\*.jpg');
len=length(imagefiles);
imageData=zeros(64*64,len);

for i=1:len
    img=imread(strcat('.\places\Images\',imagefiles(i).name));
    img=imresize(img,[64,64]);
    img=im2gray(img); 
    imageData(:,i)=img(:);
end

testfiles=dir('.\places\Test\*.jpg');
testlen=length(testfiles);
testData=zeros(64*64,testlen);

for i=1:testlen
    img=imread(strcat('.\places\Test\',testfiles(i).name));
    img=imresize(img,[64,64]);
    img=im2gray(img); 
    testData(:,i)=img(:);
end

%f=1;
% problem b
for j=1:testlen
    distMat=zeros(1,len);
    for i=1:len
        dist=sqrt(sum((testData(:,j)-imageData(:,i)).^2));
        distMat(i)=dist;      
    end
    minDist=min(distMat);
    minIndex=find(distMat==minDist);
    figure;
    subplot(1,2,1);
    limg=imread(strcat('.\places\Test\',testfiles(j).name));
    imshow(limg);
    title(testfiles(j).name);
    subplot(1,2,2);
    rimg=strcat('.\places\Images\',imagefiles(minIndex).name);
    imshow(rimg);
    title(strcat('Match for',{' '},testfiles(j).name));
    %f=f+2;    
end

% problem c
[PC, V] = pca(imageData);
PC = PC(:,1:20);

figure;
for i= 1:20
    subplot(4,5,i);
    temp = reshape(PC(:,i),[64 64]);
    imshow(temp,[]);
end
sgtitle('First 20 Eigen-Vectors obtained from PCA');

% problem d
testpca=zeros(20,testlen);
testrecover=zeros(4096,testlen);

for i=1:testlen
    im_test= imread(strcat('.\places\Test\',testfiles(i).name));
    im_test= im2gray(im_test);
    im_test= im2double(im_test);
    im_test= imresize(im_test,[64,64]);
    im_test= im_test(:)';
    
    im_pca= im_test*PC;
    
    im_recover= im_pca*PC';
    im_recover= reshape(im_recover,[64 64]);
    im_pca=im_pca';
    testpca(:,i)=im_pca(:);
    testrecover(:,i)=im_recover(:);
    
end

imagespca=zeros(20,len);
imagesrecover=zeros(4096,len);

for i=1:len
    im_test= imread(strcat('.\places\Images\',imagefiles(i).name));
    im_test= im2gray(im_test);
    im_test= im2double(im_test);
    im_test= imresize(im_test,[64,64]);
    im_test= im_test(:)';
    
    im_pca= im_test*PC;
    im_recover= im_pca*PC';
    im_pca=im_pca';
    imagespca(:,i)=im_pca(:);
    imagesrecover(:,i)=im_recover(:);
end


for j=1:testlen
    
    distMat=zeros(1,len);
    for i=1:len
        dist=sqrt(sum((testpca(:,j)-imagespca(:,i)).^2));
        distMat(i)=dist;      
    end
    minDist=min(distMat);
    minIndex=find(distMat==minDist);
    figure('Name','Using PCA');
    subplot(1,2,1);
    limg=imread(strcat('.\places\Test\',testfiles(j).name));
    imshow(limg);
    title(testfiles(j).name);
    subplot(1,2,2);
    rimg=strcat('.\places\Images\',imagefiles(minIndex).name);
    imshow(rimg);
    title(strcat('Match for',{' '},testfiles(j).name, ...
        {' '},':',{' '},imagefiles(minIndex).name));
    %f=f+2;    
    lpcimg=reshape(testrecover(:,j),[64,64]);
    rpcimg=reshape(imagesrecover(:,minIndex),[64,64]);
    figure('Name','Principal Component Comparision');
    subplot(1,2,1);
    imshow(lpcimg,[])
    title(strcat('PC of',{' '}, testfiles(j).name));
    subplot(1,2,2);
    imshow(rpcimg,[])
    title(strcat('PC of',{' '},imagefiles(minIndex).name));

end

% problem-e
imagespca5=zeros(5,testlen);
for i=1:testlen
    im_test= imread(strcat('.\places\Test\',testfiles(i).name));
    im_test= im2gray(im_test);
    im_test= im2double(im_test);
    im_test= imresize(im_test,[64,64]);
    im_test= im_test(:)';
    
    im_pca= im_test*PC(:,1:5);
    im_pca=im_pca';
    imagespca5(:,i)=im_pca(:);   
end
figure;
spider_plot(imagespca5,'AxesLabels',{'PC1','PC2','PC3','PC4','PC5'});




